<?php
include "dbcon.php";

if(isset($_POST['confirm']))
{
	$a = $_POST['n_password'];
	$b = $_POST['cn_password'];

	if($a==$b)
	{
		
	}

}

?>