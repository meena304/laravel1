<?php

$con = mysqli_connect('localhost','root','', 'tele_calling');

?>